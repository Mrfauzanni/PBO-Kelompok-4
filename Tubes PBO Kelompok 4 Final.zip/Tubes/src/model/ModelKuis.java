/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import tubes.Kuis;

public class ModelKuis {
    private ArrayList<Kuis> daftarKuis;

    public ModelKuis() {
        this.daftarKuis = new ArrayList<>();
    }

    // Metode untuk menambahkan kuis ke daftar
    public void tambahKuis(Kuis kuis) {
        daftarKuis.add(kuis);
    }

    // Metode untuk mendapatkan kuis berdasarkan pertanyaan
    public Kuis getKuisByPertanyaan(String pertanyaan) {
        for (Kuis kuis : daftarKuis) {
            if (kuis.getPertanyaan().equals(pertanyaan)) {
                return kuis;
            }
        }
        return null;
    }

    // Metode untuk menghapus kuis dari daftar
    public void hapusKuis(Kuis kuis) {
        daftarKuis.remove(kuis);
    }

    // Metode untuk menampilkan daftar kuis
    public void tampilkanDaftarKuis() {
        System.out.println("Daftar Kuis:");
        for (Kuis kuis : daftarKuis) {
            System.out.println("Pertanyaan: " + kuis.getPertanyaan() + ", Bobot Nilai: " + kuis.getBobotNilai());
        }
    }
}
