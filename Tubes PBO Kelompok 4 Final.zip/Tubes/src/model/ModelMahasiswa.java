
package model;

import java.util.ArrayList;
import tubes.Mahasiswa;

public class ModelMahasiswa {
    private ArrayList<Mahasiswa> daftarMahasiswa;

    public ModelMahasiswa() {
        this.daftarMahasiswa = new ArrayList<>();
    }

    // Metode untuk menambahkan mahasiswa ke daftar
    public void tambahMahasiswa(Mahasiswa mahasiswa) {
        daftarMahasiswa.add(mahasiswa);
    }

    // Metode untuk mendapatkan mahasiswa berdasarkan NIM
    public Mahasiswa getMahasiswaByNIM(String nim) {
        for (Mahasiswa mahasiswa : daftarMahasiswa) {
            if (mahasiswa.getNim().equals(nim)) {
                return mahasiswa;
            }
        }
        return null;
    }

    // Metode untuk menghapus mahasiswa dari daftar
    public void hapusMahasiswa(Mahasiswa mahasiswa) {
        daftarMahasiswa.remove(mahasiswa);
    }

    // Metode untuk menampilkan daftar mahasiswa
    public void tampilkanDaftarMahasiswa() {
        System.out.println("Daftar Mahasiswa:");
        for (Mahasiswa mahasiswa : daftarMahasiswa) {
            System.out.println("NIM: " + mahasiswa.getNim() + ", Nama: " + mahasiswa.getNama());
        }
    }
}
