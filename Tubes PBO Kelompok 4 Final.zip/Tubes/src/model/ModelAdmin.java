/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import tubes.Admin;

public class ModelAdmin {
    private ArrayList<Admin> daftarAdmin;

    public ModelAdmin() {
        this.daftarAdmin = new ArrayList<>();
    }

    // Metode untuk menambahkan admin ke daftar
    public void tambahAdmin(Admin admin) {
        daftarAdmin.add(admin);
    }

    // Metode untuk mendapatkan admin berdasarkan ID
    public Admin getAdminByID(String id) {
        for (Admin admin : daftarAdmin) {
            if (admin.getId().equals(id)) {
                return admin;
            }
        }
        return null;
    }

    // Metode untuk menghapus admin dari daftar
    public void hapusAdmin(Admin admin) {
        daftarAdmin.remove(admin);
    }

    // Metode untuk menampilkan daftar admin
    public void tampilkanDaftarAdmin() {
        System.out.println("Daftar Admin:");
        for (Admin admin : daftarAdmin) {
            System.out.println("ID: " + admin.getId());
        }
    }
}
