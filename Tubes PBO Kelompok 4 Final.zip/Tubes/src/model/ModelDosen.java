package model;
import tubes.Dosen;
import java.util.ArrayList;

public class ModelDosen {
    private ArrayList<Dosen> daftarDosen;

    public ModelDosen() {
        this.daftarDosen = new ArrayList<>();
    }

    // Metode untuk menambahkan dosen ke daftar
    public void tambahDosen(Dosen dosen) {
        daftarDosen.add(dosen);
    }

    // Metode untuk mendapatkan dosen berdasarkan NIP
    public Dosen getDosenByNIP(String nip) {
        for (Dosen dosen : daftarDosen) {
            if (dosen.getNip().equals(nip)) {
                return dosen;
            }
        }
        return null;
    }

    // Metode untuk menghapus dosen dari daftar
    public void hapusDosen(Dosen dosen) {
        daftarDosen.remove(dosen);
    }

    // Metode untuk menampilkan daftar dosen
    public void tampilkanDaftarDosen() {
        System.out.println("Daftar Dosen:");
        for (Dosen dosen : daftarDosen) {
            System.out.println("NIP: " + dosen.getNip() + ", Nama: " + dosen.getNama());
        }
    }
}
