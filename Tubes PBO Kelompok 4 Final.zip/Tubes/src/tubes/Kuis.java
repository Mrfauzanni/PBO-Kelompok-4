package tubes;
import java.util.ArrayList;

public class Kuis {
    private int idKuis;
    private ArrayList<String> pertanyaan;
    private ArrayList<String> jawaban;
    private int bobotNilai;


    public Kuis(int idKuis, ArrayList<String> pertanyaan, ArrayList<String> jawaban, double bobotNilai) {
        this.idKuis = idKuis;
        this.pertanyaan = pertanyaan;
        this.jawaban = jawaban;
    }

    public int getIdKuis() {
        return idKuis;
    }

    public ArrayList<String> getPertanyaan() {
        return pertanyaan;
    }

    public ArrayList<String> getJawaban() {
        return jawaban;
    }

    public void setIdKuis(int idKuis) {
        this.idKuis = idKuis;
    }

    public void setPertanyaan(ArrayList<String> pertanyaan) {
        this.pertanyaan = pertanyaan;
    }

    public void setJawaban(ArrayList<String> jawaban) {
        this.jawaban = jawaban;
    }

    public int getBobotNilai() {
        return bobotNilai;
    }
    
    
    
    
}

    

    