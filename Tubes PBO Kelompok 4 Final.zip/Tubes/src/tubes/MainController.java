package tubes;
import model.ModelAdmin;
import model.ModelDosen;
import model.ModelKuis;
import model.ModelMahasiswa;
public class MainController {
    private ModelMahasiswa modelMahasiswa;
    private ModelDosen modelDosen;
    private ModelAdmin modelAdmin;
    private ModelKuis modelKuis;
    private MahasiswaView mahasiswaView;
    private DosenView dosenView;
    private AdminView adminView;
    private KuisView kuisView;
    private LoginView loginView;
    private LoginController loginController;

    public MainController() {
        // Inisialisasi model
        modelMahasiswa = new ModelMahasiswa();
        modelDosen = new ModelDosen();
        modelAdmin = new ModelAdmin();
        modelKuis = new ModelKuis();

        // Inisialisasi view
        mahasiswaView = new MahasiswaView();
        dosenView = new DosenView();
        adminView = new AdminView();
        kuisView = new KuisView();
        loginView = new LoginView();

        // Inisialisasi controller
        loginController = new LoginController(this, loginView);
    }

    public void start() {
        // Implementasi login
        boolean loginSuccess = login();
        if (loginSuccess) {
            // Menjalankan aplikasi setelah login berhasil
            tampilkanMenu();
        } else {
            loginView.tampilkanPesan("Login gagal. Aplikasi berhenti.");
        }
    }


    private void tampilkanMenu() {
        // Tampilkan menu dan terapkan logika interaksi selanjutnya di sini
        // Misalnya, memanggil metode dari controller untuk mengelola kuis, mahasiswa, dll.
    }

    public static void main(String[] args) {
        MainController mainController = new MainController();
        mainController.start();
    }

    private boolean login() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
