package tubes;
import java.util.ArrayList;
import tubes.Mahasiswa;


public class Dosen {
    private String nip;
    private String nama;
    private ArrayList<Kuis> daftarKuis;

    // Konstruktor
    public Dosen(String nip, String nama) {
        this.nip = nip;
        this.nama = nama;
        this.daftarKuis = new ArrayList<>();
    }

    public String getNip() {
        return nip;
    }

    public String getNama() {
        return nama;
    }

    public ArrayList<Kuis> getDaftarKuis() {
        return daftarKuis;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setDaftarKuis(ArrayList<Kuis> daftarKuis) {
        this.daftarKuis = daftarKuis;
    }
    

    // Metode buat kuis
    public void buatKuis(Kuis kuis) {
        daftarKuis.add(kuis);
    }

    // Metode hapus kuis
    public void hapusKuis(Kuis kuis) {
        daftarKuis.remove(kuis);
    }

    // Metode lihat nilai mahasiswa
    public void lihatNilaiMahasiswa(Mahasiswa mahasiswa) {
        mahasiswa.lihatHasilKuis();
    }
}