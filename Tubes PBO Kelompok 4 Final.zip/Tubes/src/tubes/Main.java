/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubes;

import Database.Database;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Database database = new Database();
        Scanner scanner = new Scanner(System.in);

        // Inisialisasi controller
        MainController mainController = new MainController(database);

        // Implementasi login
        boolean loginSuccess = mainController.login(scanner);
        
        if (loginSuccess) {
            // Menjalankan aplikasi setelah login berhasil
            mainController.tampilkanMenu(scanner);
        } else {
            System.out.println("Login gagal. Aplikasi berhenti.");
        }

        // Tutup koneksi ke database
        database.closeConnection();
    }
}
